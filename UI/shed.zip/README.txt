How to run:

You can run the Sim.java in the src/test/java/org/simulator you can modify the number of clients that can run directly from the code, as well as the test it will run(coordinator/token). 

You can modify the command file in src/test/resources.
